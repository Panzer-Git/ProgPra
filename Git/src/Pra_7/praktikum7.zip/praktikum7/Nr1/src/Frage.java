public class Frage {
    private String fragenText;

    Frage(String fragenText){
        this.fragenText = fragenText;
    }

    public String getFragenText() {
        return fragenText;
    }
    public void setFragenText(String fragenText) {
        this.fragenText = fragenText;
    }
}
