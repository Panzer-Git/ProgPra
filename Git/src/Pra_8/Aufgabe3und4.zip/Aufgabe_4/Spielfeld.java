package Pra_8.Aufgabe_4;

import java.util.HashMap;
import java.util.Scanner;

public class Spielfeld {
    HashMap<Character, Auto> feld = new HashMap<>();
    Scanner input;

    public Spielfeld(String construction) {
        HashMap<Character, Auto> vorfeld = new HashMap<>();
        for (int i = 0; i < construction.length(); i++) {
            char currentChar = construction.charAt(i);
            int[] strPos = iPos(i);
            if (currentChar != '_') {
                if (!vorfeld.containsKey(currentChar)) {
                    vorfeld.put(currentChar, new Auto(strPos,currentChar));
                } else {
                    vorfeld.get(construction.charAt(i)).addToPos(strPos);
                }
            }
        }
        this.input = new Scanner(System.in);
        this.feld = vorfeld;
    }

    public void printFeld() {
        char[][] vorfeld = this.feldStatus();
        for (char c : this.feld.keySet()) {
            vorfeld = this.feld.get(c).setzeDich(vorfeld);
        }
        String resultString = "";
        for (int i = 0; i < 6; i++) {
            resultString += "+--+--+--+--+--+--+\n";
            for (int j = 0; j < 6; j++) {
                resultString += "|" + vorfeld[i][j] + " ";
            }
            resultString += "|\n";
        }
        resultString += "+--+--+--+--+--+--+\n";
        System.out.println(resultString);
    }

    public char[][] feldStatus() {
        char[][] vorfeld = {{'_','_','_','_','_','_'},{'_','_','_','_','_','_'},{'_','_','_','_','_','_'},{'_','_','_','_','_','_'},{'_','_','_','_','_','_'},{'_','_','_','_','_','_'}};
        for (char c : this.feld.keySet()) {
            vorfeld = this.feld.get(c).setzeDich(vorfeld);
        }
        return vorfeld;
    }
    public boolean checkGewinn() {
        return this.feld.get('*').checkGewinn();
    }

    public void zug() {
        Auto.ganzFeld = this.feldStatus();
        System.out.println("Wahl eines Autos (Zeichen angeben):");
        char inputChar = input.nextLine().charAt(0);
        if (!this.feld.containsKey(inputChar)) {
            System.out.println("Kein valides Auto");
            this.zug();
        } else {
            System.out.println("Richtung (l = links, r = rechts, u = hoch, d = runter, q = zurück):");
            char inputChar2 = input.nextLine().charAt(0);
            if (!this.feld.get(inputChar).move(inputChar2)) {
                this.zug();
            }
        }
    }

    public int[] iPos(int i) {
        int[] strPos = new int[]{0,0};
        if (i > 29) {
            strPos[0] = 5;
        } else if (i > 23) {
            strPos[0] = 4;
        } else if (i > 17) {
            strPos[0] = 3;
        } else if (i > 11) {
            strPos[0] = 2;
        } else if (i > 5) {
            strPos[0] = 1;
        }
        strPos[1] = i - strPos[0]*6;
        return strPos;
    }
}
