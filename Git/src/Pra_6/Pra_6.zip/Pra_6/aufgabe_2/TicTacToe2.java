package Pra_6.aufgabe_2;

public class TicTacToe2 {
    public static void main(String[] args) {
        Spiel spiel = new Spiel();
        spiel.starte();
    }
}
